
    
    <!-- Core Vendors JS -->
    <script src="assets/js/vendors.min.js"></script>

    <!-- page js -->

    <!-- Core JS -->
    <script src="assets/js/app.min.js"></script>

      
  <!-- Core JS -->
  <script src="assets/js/app.min.js"></script>

  <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
      <script>
          $(document).ready(function() {
              $('#myTable1').DataTable();
          } );
      </script>
      <script>
          $(document).ready(function() {
              $('#myTable2').DataTable();
          } );
      </script>