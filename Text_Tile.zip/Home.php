<!-- Header START -->
<?php
include("include/Header.php");
?>
<!-- Side Nav END -->

<!-- Footer START -->
<?php
include("include/Footer.php");
?>
<!-- Footer END -->
<!-- Core Vendors JS -->
<?php
include("include/Script.php");
?>