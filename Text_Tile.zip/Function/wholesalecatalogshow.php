<?php

    
    $sql = "SELECT * FROM `wholesalecatalog`";
    $result = mysqli_query($conn, $sql);

?>