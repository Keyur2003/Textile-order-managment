<?php

    
    $sql = "SELECT * FROM `retailscatalog`";
    $result = mysqli_query($conn, $sql);

?>